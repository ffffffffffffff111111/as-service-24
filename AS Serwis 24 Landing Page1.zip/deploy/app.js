/* ===== AS Serwis 24 — shared interactions + i18n ===== */
(function () {
  'use strict';

  var LS_KEY = 'as24_lang';

  var I18N = {
    // nav
    'nav.hol': { pl: 'Pomoc drogowa', en: 'Roadside help' },
    'nav.tir': { pl: 'Mobilny serwis TIR', en: 'Mobile truck service' },
    'nav.opony': { pl: 'Wymiana opon', en: 'Tyre service' },
    'nav.diag': { pl: 'Diagnostyka', en: 'Diagnostics' },
    'nav.kontakt': { pl: 'Kontakt', en: 'Contact' },
    // hero (home)
    'hero.badge': { pl: 'Pomoc drogowa 24h', en: 'Roadside assistance 24h' },
    'hero.h1': { pl: 'Twój TIR stanął.|My już jedziemy.', en: 'Your truck broke down.|We are already rolling.' },
    'hero.sub': { pl: 'Mobilny serwis ciężarówek i holowanie TIR 24/7. Naprawa na miejscu lub bezpieczny transport do warsztatu, działamy szybko, przez całą dobę.', en: 'Mobile truck service and truck towing 24/7. Repaired on site or safely transported to the workshop, fast, around the clock.' },
    'hero.cta': { pl: 'Zadzwoń teraz · 791 656 158', en: 'Call now · 791 656 158' },
    'stat.availability': { pl: 'dostępność, całą dobę', en: 'available, around the clock' },
    'stat.countries': { pl: 'krajów obsługi', en: 'countries covered' },
    'stat.reviews': { pl: 'opinii w Google', en: 'Google reviews' },
    // home service overview
    'ov.kicker': { pl: 'Zakres usług', en: 'What we do' },
    'ov.h2': { pl: 'Cztery filary pomocy w trasie.', en: 'Four pillars of help on the road.' },
    'ov.tir.t': { pl: 'Mobilny serwis TIR', en: 'Mobile truck service' },
    'ov.tir.d': { pl: 'Warsztat, który przyjeżdża na pobocze: mechanika, elektryka, układ pneumatyczny i hamulcowy.', en: 'A workshop that comes to the hard shoulder: mechanics, electrics, air and brake systems.' },
    'ov.hol.t': { pl: 'Pomoc drogowa i holowanie', en: 'Roadside help and towing' },
    'ov.hol.d': { pl: 'Gdy naprawa na miejscu nie wystarczy: holowanie i bezpieczny transport TIR-a do warsztatu.', en: 'When an on-site repair is not enough: towing and safe transport of the truck to a workshop.' },
    'ov.opony.t': { pl: 'Wymiana opon', en: 'Tyre service' },
    'ov.opony.d': { pl: 'Wymiana i naprawa opon ciężarowych, koła zapasowe, mobilny wulkanizator o każdej porze.', en: 'Truck tyre replacement and repair, spare wheels, mobile fitting at any hour.' },
    'ov.diag.t': { pl: 'Diagnostyka komputerowa', en: 'Computer diagnostics' },
    'ov.diag.d': { pl: 'Odczyt i kasowanie błędów, elektronika, systemy AdBlue i SCR, diagnoza w drodze.', en: 'Fault reading and clearing, electronics, AdBlue and SCR systems, diagnosis on the road.' },
    'ov.more': { pl: 'Dowiedz się więcej', en: 'Learn more' },
    // holowanie
    'hol.kicker': { pl: 'Gdy naprawa nie wystarczy', en: 'When a repair is not enough' },
    'hol.h2': { pl: 'Pomoc drogowa i holowanie TIR 24/7', en: 'Roadside assistance and truck towing 24/7' },
    'hol.desc': { pl: 'Nie każdą awarię da się usunąć na miejscu. Jeśli naprawa okazuje się niemożliwa, organizujemy profesjonalną pomoc drogową oraz holowanie samochodów ciężarowych. Działamy 24 godziny na dobę, zapewniając szybki dojazd, zabezpieczenie pojazdu i bezpieczny transport do wskazanego warsztatu.', en: 'Not every breakdown can be fixed on the spot. If a repair proves impossible, we arrange professional roadside assistance and truck towing. We operate around the clock, ensuring a fast arrival, securing of the vehicle and safe transport to the workshop of your choice.' },
    'h1.title': { pl: 'Holowanie ciężarówek', en: 'Truck towing' },
    'h1.desc': { pl: 'Holowanie samochodów ciężarowych i zestawów do wskazanego warsztatu, o każdej porze.', en: 'Towing of trucks and full rigs to the workshop of your choice, at any hour.' },
    'h2.title': { pl: 'Wyciąganie pojazdów', en: 'Vehicle recovery' },
    'h2.desc': { pl: 'Wyciąganie pojazdów po awarii lub kolizji, także z rowu i trudnego terenu.', en: 'Recovery of vehicles after a breakdown or collision, including from ditches and rough ground.' },
    'h3.title': { pl: 'Zabezpieczenie miejsca', en: 'Scene protection' },
    'h3.desc': { pl: 'Zabezpieczenie miejsca zdarzenia i pojazdu, by droga i ładunek pozostały bezpieczne.', en: 'Securing the scene and the vehicle so the road and cargo stay safe.' },
    'h4.title': { pl: 'Transport do warsztatu', en: 'Transport to the workshop' },
    'h4.desc': { pl: 'Transport TIR-ów do warsztatu, dowieziemy pojazd tam, gdzie zostanie naprawiony.', en: 'Transport of trucks to the workshop, we deliver the vehicle where it will be repaired.' },
    'h5.title': { pl: 'Pomoc drogowa 24/7', en: 'Roadside assistance 24/7' },
    'h5.desc': { pl: 'Jesteśmy dostępni całą dobę, siedem dni w tygodniu, także w weekendy i święta.', en: 'We are available around the clock, seven days a week, including weekends and holidays.' },
    'h6.title': { pl: 'Trasy w całej Europie', en: 'Routes across Europe' },
    'h6.desc': { pl: 'Wsparcie na trasach w Polsce i Europie Środkowej, tam, gdzie akurat jesteś.', en: 'Support on routes across Poland and Central Europe, wherever you happen to be.' },
    // mobilny serwis tir
    'tir.kicker': { pl: 'Co robimy na miejscu', en: 'What we do on site' },
    'tir.h1': { pl: 'Mobilny serwis ciężarówek, który przyjeżdża do ciebie.', en: 'A mobile truck service that comes to you.' },
    'tir.sub': { pl: 'Warsztat na kołach z częściami i narzędziami. Naprawiamy na poboczu, parkingu i w bazie, przez całą dobę, w Polsce i Europie Środkowej.', en: 'A workshop on wheels with parts and tools. We repair on the hard shoulder, in car parks and at our base, around the clock, across Poland and Central Europe.' },
    's1.title': { pl: 'Naprawa mechaniczna', en: 'Mechanical repair' },
    's1.desc': { pl: 'Silnik, sprzęgło, zawieszenie, układ pneumatyczny i hamulcowy: diagnoza i naprawa na trasie.', en: 'Engine, clutch, suspension, air and brake systems: diagnosis and repair on the road.' },
    's2.title': { pl: 'Elektryka i rozruch', en: 'Electrics and starting' },
    's2.desc': { pl: 'Awarie instalacji, alternatory, rozruszniki, doładowanie i wymiana akumulatorów w terenie.', en: 'Wiring faults, alternators, starters, jump-starts and battery replacement in the field.' },
    's3.title': { pl: 'Układ pneumatyczny i hamulcowy', en: 'Air and brake systems' },
    's3.desc': { pl: 'Nieszczelności, zawory, miechy i hamulce: usuwamy usterki, które zatrzymują zestaw.', en: 'Leaks, valves, air bags and brakes: we fix the faults that stop a rig.' },
    // wymiana opon
    'op.kicker': { pl: 'Serwis ogumienia 24/7', en: 'Tyre service 24/7' },
    'op.h1': { pl: 'Wymiana i naprawa opon ciężarowych na trasie.', en: 'Truck tyre replacement and repair on the road.' },
    'op.sub': { pl: 'Strzeliła opona w środku nocy? Dojeżdżamy z kołem i sprzętem, wymieniamy lub naprawiamy na miejscu i wracasz na trasę.', en: 'A blowout in the middle of the night? We arrive with a wheel and equipment, replace or repair on the spot, and you are back on the road.' },
    'o1.title': { pl: 'Wymiana opon', en: 'Tyre replacement' },
    'o1.desc': { pl: 'Wymiana opon ciężarowych i naczep na miejscu, bez holowania do warsztatu.', en: 'Truck and trailer tyre replacement on site, with no towing to a workshop.' },
    'o2.title': { pl: 'Naprawa i wulkanizacja', en: 'Repair and vulcanising' },
    'o2.desc': { pl: 'Mobilny wulkanizator: łatanie i naprawa uszkodzonych opon, gdy da się je uratować.', en: 'Mobile fitter: patching and repair of damaged tyres when they can be saved.' },
    'o3.title': { pl: 'Koła zapasowe', en: 'Spare wheels' },
    'o3.desc': { pl: 'Dowóz i montaż koła zapasowego, byś nie utknął bez sprawnego ogumienia.', en: 'Delivery and fitting of a spare wheel so you never get stuck without a working tyre.' },
    // diagnostyka
    'dg.kicker': { pl: 'Diagnostyka komputerowa', en: 'Computer diagnostics' },
    'dg.h1': { pl: 'Znajdujemy przyczynę, nie tylko objaw.', en: 'We find the cause, not just the symptom.' },
    'dg.sub': { pl: 'Komputer diagnostyczny w każdym wyjeździe. Odczytujemy błędy, sprawdzamy elektronikę i systemy emisji, byś wiedział, co naprawdę się dzieje z pojazdem.', en: 'A diagnostic computer on every call-out. We read faults, check the electronics and emission systems so you know what is really happening with the vehicle.' },
    'd1.title': { pl: 'Odczyt i kasowanie błędów', en: 'Fault reading and clearing' },
    'd1.desc': { pl: 'Podłączamy komputer, odczytujemy kody usterek i kasujemy je po naprawie.', en: 'We connect the computer, read fault codes and clear them after the repair.' },
    'd2.title': { pl: 'Elektronika i czujniki', en: 'Electronics and sensors' },
    'd2.desc': { pl: 'Diagnoza czujników, sterowników i instalacji, które wprowadzają pojazd w tryb awaryjny.', en: 'Diagnosis of sensors, controllers and wiring that put the vehicle into limp mode.' },
    'd3.title': { pl: 'AdBlue, SCR i emisja', en: 'AdBlue, SCR and emissions' },
    'd3.desc': { pl: 'Usterki układu AdBlue i SCR, które ograniczają moc: lokalizujemy i usuwamy problem.', en: 'AdBlue and SCR faults that limit power: we locate and fix the problem.' },
    // how it works
    'jak.kicker': { pl: 'Jak to działa', en: 'How it works' },
    'jak.h2': { pl: 'Trzy kroki od awarii do wyjazdu.', en: 'Three steps from breakdown to back on the road.' },
    'k1.label': { pl: 'KROK 01', en: 'STEP 01' },
    'k1.title': { pl: 'Dzwonisz', en: 'You call' },
    'k1.desc': { pl: 'Odbieramy o każdej porze. Podajesz lokalizację i objaw usterki, resztę bierzemy na siebie.', en: 'We answer any time. You give your location and the symptom, we take care of the rest.' },
    'k2.label': { pl: 'KROK 02', en: 'STEP 02' },
    'k2.title': { pl: 'Jedziemy', en: 'We drive out' },
    'k2.desc': { pl: 'Mobilny warsztat rusza z częściami i narzędziami. Śledzisz nasz dojazd, znasz orientacyjny czas.', en: 'The mobile workshop sets off with parts and tools. You track our arrival and know the ETA.' },
    'k3.label': { pl: 'KROK 03', en: 'STEP 03' },
    'k3.title': { pl: 'Naprawiamy na miejscu', en: 'We fix it on site' },
    'k3.desc': { pl: 'Usterkę usuwamy tam, gdzie stoisz. Jeśli naprawa na miejscu nie jest możliwa, organizujemy profesjonalne holowanie i bezpieczny transport pojazdu, aby jak najszybciej przywrócić Cię do pracy.', en: 'We fix the fault where you stand. If an on-site repair is not possible, we arrange professional towing and safe transport of the vehicle to get you back to work as fast as possible.' },
    // coverage
    'gdzie.kicker': { pl: 'Gdzie jesteśmy', en: 'Where we operate' },
    'gdzie.h2': { pl: 'Baza w Żywcu, zasięg przez pół Europy.', en: 'Based in Żywiec, reaching across half of Europe.' },
    'gdzie.p': { pl: 'Wyjeżdżamy z południa Polski i obsługujemy całą Europę Środkową, tam gdzie stoi twoja ciężarówka.', en: 'We set off from southern Poland and cover the whole of Central Europe, wherever your truck stands.' },
    'c.pl': { pl: 'Polska', en: 'Poland' },
    'c.at': { pl: 'Austria', en: 'Austria' },
    'c.cz': { pl: 'Czechy', en: 'Czechia' },
    'c.sk': { pl: 'Słowacja', en: 'Slovakia' },
    'c.de': { pl: 'Niemcy', en: 'Germany' },
    'c.hu': { pl: 'Węgry', en: 'Hungary' },
    'map.note': { pl: 'Poza tym obszarem nie dojeżdżamy.', en: 'We do not travel beyond this area.' },
    'map.plus': { pl: 'Plus code M69V+VH · Otwórz w Mapach Google', en: 'Plus code M69V+VH · Open in Google Maps' },
    // reviews
    'rev.kicker': { pl: 'Opinie', en: 'Reviews' },
    'rev.h2': { pl: 'Kierowcy, którym pomogliśmy wrócić na trasę.', en: 'Drivers we helped get back on the road.' },
    'rev.count': { pl: '94 opinii w Google · zobacz profil', en: '94 Google reviews · view profile' },
    // contact
    'kon.kicker': { pl: 'Kontakt', en: 'Contact' },
    'kon.h1': { pl: 'Zadzwoń. Odbieramy o każdej porze.', en: 'Call us. We answer at any hour.' },
    'kon.sub': { pl: 'Jeden telefon i ruszamy. Podaj lokalizację i objaw usterki, a my zajmiemy się resztą, 24 godziny na dobę, 7 dni w tygodniu.', en: 'One call and we set off. Give us your location and the symptom, and we take care of the rest, 24 hours a day, 7 days a week.' },
    'kon.phone.t': { pl: 'Telefon 24/7', en: 'Phone 24/7' },
    'kon.addr.t': { pl: 'Baza', en: 'Base' },
    'kon.hours.t': { pl: 'Godziny', en: 'Hours' },
    'kon.hours.v': { pl: 'Czynne całą dobę, 7 dni w tygodniu, także w weekendy i święta.', en: 'Open around the clock, 7 days a week, including weekends and holidays.' },
    'kon.area.t': { pl: 'Zasięg', en: 'Coverage' },
    'kon.area.v': { pl: 'Polska i Europa Środkowa: Austria, Czechy, Słowacja, Niemcy, Węgry.', en: 'Poland and Central Europe: Austria, Czechia, Slovakia, Germany, Hungary.' },
    // cta band + footer
    'cta.h2': { pl: 'Stoisz na trasie? Nie czekaj do rana.', en: 'Stuck on the road? Do not wait until morning.' },
    'cta.btn': { pl: 'Zadzwoń teraz · 791 656 158', en: 'Call now · 791 656 158' },
    'footer.hours': { pl: 'Czynne całą dobę, 7 dni w tygodniu', en: 'Open around the clock, 7 days a week' }
  };

  var REVIEWS = [
    { initials: 'MM', name: 'Mateusz Matras', meta: 'Scania R · siłownik', text: '„Polecam! Szybki dojazd, mechanik Adam w sprawny sposób uporał się z usterką siłownika w Scanii R. Ogarnięty gość, rozsądna cena za naprawę.”' },
    { initials: 'JB', name: 'Julia Bińkowska', meta: 'Austria · ciężarówka', text: '„Zaśnieżona Austria, zero możliwości ruszenia ciężarówką. Gdyby nie serwis AS, byłby ogromny problem ze zjazdem do Polski. Solidna firma, dobry fachowiec, świetny kontakt. Polecam z całego serca.”' },
    { initials: 'KS', name: 'Krzysztof Szewczyk', meta: 'Opona · weekend', text: '„W sobotę wieczorem, w trakcie świąt, pomogli mi błyskawicznie załatać dziurę w oponie. Szybka reakcja, profesjonalna obsługa i pełne zaangażowanie mimo nietypowej pory.”' },
    { initials: 'MM', name: 'Michał Mielcarek', meta: 'Naprawa za granicą', text: '„Prosta, rzeczowa rozmowa przez telefon i ustalenie ceny. Część znaleziona wieczorem we własnym magazynie, szybki dojazd na naprawę za granicę i stały kontakt. Auto po pauzie ruszyło dalej.”' },
    { initials: 'PG', name: 'Paweł Grabowski', meta: 'Słowacja', text: '„Bardzo dobry kontakt z właścicielem przed, w trakcie i po naprawie. Profesjonalny sprzęt i duże chęci. Awaria w Słowacji została błyskawicznie załatwiona. Polecam!”' },
    { initials: 'AB', name: 'Ana Bariana', meta: 'Nocna pomoc', text: '„Obsługa pierwsza klasa! Telefon odebrany w środku nocy, szybka diagnoza, błyskawiczny dojazd i fachowa naprawa w rozsądnej cenie uratowały mój wyjazd. Polecam!”' },
    { initials: 'DG', name: 'Dariusz Goźliński', meta: 'Diagnoza w drodze', text: '„Pełen profesjonalizm. Telefon, dojazd, szybka diagnoza, nowa część, wymiana i mogłem ruszać dalej. Na drugi dzień telefon, czy wszystko w porządku, to mnie zaskoczyło.”' },
    { initials: 'KW', name: 'Krzysztof Wdowczyk', meta: 'MAN · sprzęgło', text: '„W niedzielę na parkingu wymiana sprzęgła w MAN. Zrobione szybko i dobrze, a cena niższa niż u mojego lokalnego mechanika. Ponoć tak się nie da?”' },
    { initials: 'TZ', name: 'Tomasz Zawarus', meta: 'Węgry', text: '„Prawdziwy AS w naprawie pojazdów ciężarowych, pomogli nam na Węgrzech. Polecam.”' },
    { initials: 'JB', name: 'Jakub Buda', meta: 'Diagnoza telefoniczna', text: '„Mogę polecić w 100%. Wstępna diagnoza przez telefon, do 1,5h na miejscu z częściami i auto naprawione. Przy okazji zlokalizowana i usunięta inna usterka.”' }
  ];

  var lang = 'pl';
  try { lang = localStorage.getItem(LS_KEY) || 'pl'; } catch (e) {}

  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function buildH1(el, text, animate) {
    el.innerHTML = '';
    el.style.whiteSpace = 'normal';
    var lines = text.split('|');
    var wi = 0;
    lines.forEach(function (line, li) {
      line.trim().split(' ').forEach(function (w) {
        var span = document.createElement('span');
        span.textContent = w;
        span.style.display = 'inline-block';
        if (animate) {
          span.style.opacity = '0';
          span.style.filter = 'blur(12px)';
          span.style.transform = 'translateY(0.25em)';
          span.style.transition = 'opacity .7s cubic-bezier(.16,1,.3,1), filter .7s cubic-bezier(.16,1,.3,1), transform .7s cubic-bezier(.16,1,.3,1)';
          span.style.transitionDelay = (wi * 70) + 'ms';
        }
        el.appendChild(span);
        el.appendChild(document.createTextNode(' '));
        wi++;
      });
      if (li < lines.length - 1) el.appendChild(document.createElement('br'));
    });
    if (animate) {
      requestAnimationFrame(function () {
        $$('span', el).forEach(function (s) {
          s.style.opacity = '1'; s.style.filter = 'none'; s.style.transform = 'none';
        });
      });
    }
  }

  function applyLang(l) {
    lang = l;
    try { localStorage.setItem(LS_KEY, l); } catch (e) {}
    $$('[data-i18n]').forEach(function (el) {
      var entry = I18N[el.getAttribute('data-i18n')];
      if (!entry || !entry[l]) return;
      if (el.hasAttribute('data-h1')) buildH1(el, entry[l], false);
      else el.textContent = entry[l];
    });
    document.documentElement.setAttribute('lang', l);
    $$('[data-lang-btn]').forEach(function (b) {
      b.classList.toggle('on', b.getAttribute('data-lang-btn') === l);
    });
  }

  function initLang() {
    $$('[data-lang-btn]').forEach(function (b) {
      b.addEventListener('click', function () { applyLang(b.getAttribute('data-lang-btn')); });
    });
    applyLang(lang);
  }

  function initReveal() {
    var els = $$('[data-reveal]');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          var d = parseInt(e.target.getAttribute('data-reveal-delay') || '0', 10);
          e.target.style.transitionDelay = d + 'ms';
          e.target.classList.add('in');
        } else {
          e.target.style.transitionDelay = '0ms';
          e.target.classList.remove('in');
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    els.forEach(function (el) { io.observe(el); });
  }

  function initCounters() {
    var run = function (el) {
      var target = parseFloat(el.getAttribute('data-count'));
      var decimals = parseInt(el.getAttribute('data-count-decimals') || '0', 10);
      var dur = 1400, start = performance.now();
      var tick = function (now) {
        var p = Math.min(1, (now - start) / dur);
        var eased = 1 - Math.pow(1 - p, 3);
        var val = target * eased;
        el.textContent = decimals ? val.toFixed(decimals).replace('.', ',') : Math.round(val).toString();
        if (p < 1) requestAnimationFrame(tick);
        else el.textContent = decimals ? target.toFixed(decimals).replace('.', ',') : Math.round(target).toString();
      };
      requestAnimationFrame(tick);
    };
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) run(e.target);
        else e.target.textContent = '0';
      });
    }, { threshold: 0.5 });
    $$('[data-count]').forEach(function (el) { io.observe(el); });
  }

  function initChips() {
    var chips = $$('.chip');
    if (!chips.length) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          chips.forEach(function (c, idx) {
            setTimeout(function () { c.style.opacity = '1'; c.style.transform = 'none'; }, 100 + idx * 100);
          });
        } else {
          chips.forEach(function (c) { c.style.opacity = '0'; c.style.transform = 'translateY(10px)'; });
        }
      });
    }, { threshold: 0.3 });
    var wrap = chips[0].parentElement;
    if (wrap) io.observe(wrap);
  }

  function initRoad() {
    var path = $('#roadPath');
    if (!path) return;
    var len = path.getTotalLength();
    path.style.strokeDasharray = '' + len;
    path.style.strokeDashoffset = '' + len;
    var draw = function () {
      var rect = path.closest('svg').getBoundingClientRect();
      var vh = window.innerHeight;
      var p = Math.max(0, Math.min(1, (vh - rect.top) / (vh * 0.85)));
      path.style.opacity = (0.2 + 0.8 * p).toString();
      path.style.strokeDashoffset = (len * (1 - p)).toString();
    };
    window.addEventListener('scroll', draw, { passive: true });
    draw();
  }

  function initSplit() {
    var el = $('[data-h1]');
    if (!el) return;
    var entry = I18N[el.getAttribute('data-i18n')];
    var text = (entry && entry[lang]) || el.textContent.trim();
    buildH1(el, text, true);
  }

  function initParallax() {
    var img = $('[data-parallax]');
    if (!img) return;
    var onScroll = function () {
      var y = window.scrollY, vh = window.innerHeight;
      if (y > vh) return;
      img.style.transform = 'translateX(' + (y * 0.14) + 'px) scale(1.02)';
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function initProgress() {
    var bar = $('.progress');
    if (!bar) return;
    var onScroll = function () {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      var p = h > 0 ? Math.min(1, window.scrollY / h) : 0;
      bar.style.transform = 'scaleX(' + p + ')';
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function initNavScroll() {
    var nav = $('.nav');
    if (!nav) return;
    var onScroll = function () {
      if (window.scrollY > 40) {
        nav.style.background = 'rgba(255,255,255,0.78)';
        nav.style.boxShadow = '0 14px 50px rgba(10,10,10,0.14),inset 0 1px 0 rgba(255,255,255,0.9)';
        nav.style.top = '12px';
      } else {
        nav.style.background = 'rgba(255,255,255,0.6)';
        nav.style.boxShadow = '0 10px 40px rgba(10,10,10,0.08),inset 0 1px 0 rgba(255,255,255,0.85)';
        nav.style.top = '20px';
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function initMenu() {
    var btn = $('.menu-btn'), panel = $('.menu-panel');
    if (!btn || !panel) return;
    var bars = $$('.menu-ico > span');
    var setOpen = function (open) {
      panel.classList.toggle('open', open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.style.background = open ? 'rgba(10,10,10,0.06)' : 'rgba(255,255,255,0.55)';
      if (bars.length === 3) {
        bars[0].style.transform = open ? 'translateY(5px) rotate(45deg)' : 'none';
        bars[1].style.opacity = open ? '0' : '1';
        bars[2].style.transform = open ? 'translateY(-5px) rotate(-45deg)' : 'none';
      }
    };
    btn.addEventListener('click', function (e) { e.stopPropagation(); setOpen(!panel.classList.contains('open')); });
    $$('a', panel).forEach(function (a) { a.addEventListener('click', function () { setOpen(false); }); });
    document.addEventListener('click', function (e) {
      if (panel.classList.contains('open') && !panel.contains(e.target) && !btn.contains(e.target)) setOpen(false);
    });
    window.addEventListener('scroll', function () { if (panel.classList.contains('open')) setOpen(false); }, { passive: true });
  }

  function initMagnetic() {
    $$('[data-magnetic]').forEach(function (el) {
      el.style.transition = 'transform .35s cubic-bezier(.16,1,.3,1)';
      el.style.willChange = 'transform';
      window.addEventListener('mousemove', function (ev) {
        var r = el.getBoundingClientRect();
        var dx = ev.clientX - (r.left + r.width / 2);
        var dy = ev.clientY - (r.top + r.height / 2);
        if (Math.hypot(dx, dy) < 90) el.style.transform = 'translate(' + (dx * 0.32) + 'px,' + (dy * 0.32) + 'px)';
        else el.style.transform = 'translate(0,0)';
      }, { passive: true });
      el.addEventListener('mouseleave', function () { el.style.transform = 'translate(0,0)'; });
    });
  }

  function initCall() {
    var trigger = function (href) {
      try { window.location.href = href; } catch (e) {}
      try { if (window.top && window.top !== window) window.top.location.href = href; } catch (e) {}
    };
    $$('a[href^="tel:"]').forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); trigger(a.getAttribute('href')); });
    });
  }

  function initReviews() {
    var track = $('.rev-track');
    if (!track) return;
    var i = 0;
    var slides = REVIEWS;
    // build slides
    track.innerHTML = slides.map(function (r) {
      return '<div class="rev-slide">' +
        '<div class="rev-stars">★★★★★</div>' +
        '<p class="rev-text">' + r.text + '</p>' +
        '<div style="display:flex;align-items:center;gap:12px;">' +
        '<div class="rev-av">' + r.initials + '</div>' +
        '<div><div style="font-weight:600;font-size:15px;">' + r.name + '</div>' +
        '<div style="font-size:13px;color:#888;">' + r.meta + '</div></div></div></div>';
    }).join('');
    var dotsWrap = $('.rev-dots');
    if (dotsWrap) {
      dotsWrap.innerHTML = slides.map(function () { return '<span class="rev-dot"></span>'; }).join('');
    }
    var dots = $$('.rev-dot');
    var auto;
    var render = function () {
      track.style.transform = 'translateX(-' + (i * 100) + '%)';
      dots.forEach(function (d, idx) { d.classList.toggle('on', idx === i); });
    };
    var go = function (n) { i = ((n % slides.length) + slides.length) % slides.length; render(); reset(); };
    var reset = function () { clearInterval(auto); auto = setInterval(function () { go(i + 1); }, 6500); };
    dots.forEach(function (d, idx) { d.addEventListener('click', function () { go(idx); }); });
    var prev = $('.rev-prev'), next = $('.rev-next');
    if (prev) prev.addEventListener('click', function () { go(i - 1); });
    if (next) next.addEventListener('click', function () { go(i + 1); });
    render(); reset();
  }

  function init() {
    initLang();
    initReveal();
    initCounters();
    initChips();
    initRoad();
    initSplit();
    initParallax();
    initProgress();
    initNavScroll();
    initMenu();
    initMagnetic();
    initReviews();
    initCall();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
